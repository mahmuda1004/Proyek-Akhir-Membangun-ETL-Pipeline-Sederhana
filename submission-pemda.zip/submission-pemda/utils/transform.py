# utils/transform.py
import pandas as pd

def transform_data(data):
    df = pd.DataFrame(data)

    # Remove products tanpa harga
    df = df[~df['price'].str.contains("Unavailable", na=False)]

    # Ubah harga dari $ ke IDR
    df['price'] = df['price'].str.replace("$", "", regex=False).astype(float) * 16000

    # Rating
    df['rating'] = df['rating'].str.extract(r'(\d+\.\d+)').astype(float)

    # Colors
    df['colors'] = df['colors'].str.extract(r'(\d+)').astype(int)

    # Size & Gender
    df['size'] = df['size'].str.replace("Size: ", "").str.strip()
    df['gender'] = df['gender'].str.replace("Gender: ", "").str.strip()

    # Hapus Unknown Product
    df = df[df['title'] != "Unknown Product"]

    # Remove null & duplicates
    df = df.dropna().drop_duplicates()

    return df