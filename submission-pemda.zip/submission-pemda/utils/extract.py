# utils/extract.py
import requests
from bs4 import BeautifulSoup
from datetime import datetime
import time

def extract_data(max_pages=50):
    data = []

    for page in range(1, max_pages + 1):
        if page == 1:
            url = "https://fashion-studio.dicoding.dev/"
        else:
            url = f"https://fashion-studio.dicoding.dev/page{page}"

        try:
            res = requests.get(url)
            res.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(f"Error extract halaman {page}: {e}")
            continue

        soup = BeautifulSoup(res.text, "html.parser")
        products = soup.select(".collection-card")

        for p in products:
            title = p.select_one(".product-title").text.strip()
            
            # harga bisa berbeda format
            price_tag = p.select_one(".price") or p.select_one(".price-container .price")
            price = price_tag.text.strip() if price_tag else "Price Unavailable"
            
            rating_tag = p.select_one("p")
            rating = rating_tag.text.strip() if rating_tag else "Not Rated"
            
            colors_tag = p.select_one("p:nth-of-type(2)")
            colors = colors_tag.text.strip() if colors_tag else "0 Colors"
            
            size_tag = p.select_one("p:nth-of-type(3)")
            size = size_tag.text.strip() if size_tag else "Size: Unknown"
            
            gender_tag = p.select_one("p:nth-of-type(4)")
            gender = gender_tag.text.strip() if gender_tag else "Gender: Unknown"

            data.append({
                "title": title,
                "price": price,
                "rating": rating,
                "colors": colors,
                "size": size,
                "gender": gender,
                "timestamp": datetime.now()
            })

        # optional delay supaya server tidak kebanjiran request
        time.sleep(0.5)

    return data