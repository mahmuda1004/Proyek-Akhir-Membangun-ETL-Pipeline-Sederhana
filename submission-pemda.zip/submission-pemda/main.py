# main.py
from utils.extract import extract_data
from utils.transform import transform_data
from utils.load import load_data

def main():
    print("⏳ Mulai ekstraksi data...")
    data = extract_data(max_pages=50)  # scrap sampai 50 halaman
    print(f"Jumlah data mentah: {len(data)}")
    if not data:
        print("❌ Data kosong! Cek extract.py")
        return

    print("✅ Data berhasil diambil")
    df = transform_data(data)
    print(f"✅ Data setelah transform: {len(df)}")
    if df.empty:
        print("❌ Data hasil transform kosong!")
        return

    load_data(df)
    print("✅ Data disimpan ke CSV")

if __name__ == "__main__":
    main()