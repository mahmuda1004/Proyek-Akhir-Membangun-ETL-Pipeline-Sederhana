import pandas as pd
from utils.load import load_data

def test_load():
    df = pd.DataFrame({"a": [1,2]})
    load_data(df)
    assert True