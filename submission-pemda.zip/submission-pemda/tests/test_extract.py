from utils.extract import extract_data

def test_extract():
    data = extract_data()
    assert isinstance(data, list)