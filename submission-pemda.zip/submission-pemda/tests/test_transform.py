from utils.transform import transform_data

def test_transform():
    sample = [{
        "title": "Baju",
        "price": "$10",
        "rating": "4.5 / 5",
        "colors": "3 Colors",
        "size": "Size: M",
        "gender": "Gender: Men",
        "timestamp": "2024"
    }]

    df = transform_data(sample)
    assert df.iloc[0]["price"] == 160000